<?php

	new umiEventListener('users_login_successfull', 'users', 'onLogInCount');
