<?php

	$permissions = [
		'login' => ['customMethod']
	];
	

